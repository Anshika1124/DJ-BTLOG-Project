from django.shortcuts import render
from .models import blog

#create your views here.
def Aboutblog(request):
	obj=blog.objects.all()
	return render(request,"About.html",{"About":obj})

from django.urls import path
from .views import Aboutblog

urlpatterns = [
	path('',Aboutblog,name='About'),
]
